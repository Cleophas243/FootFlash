export function normalizeFixture(f) {
  return { provider_id:f.fixture?.id, status:f.fixture?.status?.short, elapsed:f.fixture?.status?.elapsed ?? null,
    date:f.fixture?.date, league_id:f.league?.id ?? null, league_name:f.league?.name ?? null,
    home_id:f.teams?.home?.id ?? null, home_name:f.teams?.home?.name ?? null, home_logo:f.teams?.home?.logo ?? null,
    away_id:f.teams?.away?.id ?? null, away_name:f.teams?.away?.name ?? null, away_logo:f.teams?.away?.logo ?? null,
    home_goals:f.goals?.home ?? null, away_goals:f.goals?.away ?? null };
}

export async function syncLive({ provider, pool }) {
  const fixtures = await provider.live();
  for (const f of fixtures) {
    const n = normalizeFixture(f);
    await pool.query(`INSERT INTO matches (provider_id,status,scheduled_at,competition_id,home_team,away_team,home_score,away_score)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
      ON CONFLICT (provider_id) DO UPDATE SET status=EXCLUDED.status,scheduled_at=EXCLUDED.scheduled_at,
      home_team=EXCLUDED.home_team,away_team=EXCLUDED.away_team,home_score=EXCLUDED.home_score,away_score=EXCLUDED.away_score`,
      [n.provider_id,n.status,n.date,n.league_id,n.home_name,n.away_name,n.home_goals,n.away_goals]);
  }
  return { count: fixtures.length };
}
