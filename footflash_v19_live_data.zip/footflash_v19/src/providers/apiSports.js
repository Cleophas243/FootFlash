export function createApiSportsProvider({ apiKey, baseUrl = 'https://v3.football.api-sports.io', timezone = 'Europe/Kinshasa' }) {
  async function request(path, params = {}) {
    if (!apiKey) throw new Error('FOOTBALL_API_KEY is missing');
    const url = new URL(baseUrl + path);
    for (const [k,v] of Object.entries({...params, timezone})) if (v !== undefined && v !== '') url.searchParams.set(k, v);
    const res = await fetch(url, { headers: { 'x-apisports-key': apiKey } });
    if (!res.ok) throw new Error(`Football provider HTTP ${res.status}`);
    const data = await res.json();
    if (data.errors && Object.keys(data.errors).length) throw new Error(JSON.stringify(data.errors));
    return data.response || [];
  }
  return {
    live: () => request('/fixtures', { live: 'all' }),
    fixturesByDate: (date) => request('/fixtures', { date }),
    fixture: (id) => request('/fixtures', { id }),
  };
}
