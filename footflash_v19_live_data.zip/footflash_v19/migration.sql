ALTER TABLE matches ADD COLUMN IF NOT EXISTS provider_id BIGINT;
CREATE UNIQUE INDEX IF NOT EXISTS matches_provider_id_unique ON matches(provider_id) WHERE provider_id IS NOT NULL;
