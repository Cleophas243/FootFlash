# FootFlash V19 — Real Football Data Connector

V19 adds a server-side API-SPORTS/API-FOOTBALL connector and a live-match sync endpoint.

## Setup
1. Copy `.env.example` to `.env`.
2. Put your football provider API key in `FOOTBALL_API_KEY` (never in frontend code).
3. Keep the PostgreSQL database from V18 and ensure its `matches` table has a `provider_id` column with a UNIQUE constraint. If the V18 schema does not have it, add:

```sql
ALTER TABLE matches ADD COLUMN IF NOT EXISTS provider_id BIGINT UNIQUE;
```

4. Run `npm install` then `npm start`.
5. Call `POST /api/admin/sync/live` to import current live fixtures.
6. The app reads them from `GET /api/matches/live`.

## Important
The provider documents `/fixtures?live=all` for live fixtures and states that fixture/event data is updated frequently. Do not hard-code a provider key. Before public deployment, protect sync/admin routes with authentication, add validation/rate limiting, and use production database credentials/secrets.

Without an API key, V19 still starts, but live synchronization returns a configuration error instead of fake live data.
