# FootFlash V17 — Base de données & déploiement

Cette version prépare la migration du prototype vers une base de données persistante.

## Structure
- `schema.sql` : tables users, players, competitions, matches, match_events, news, transfers, notifications.
- `docker-compose.yml` : PostgreSQL pour le développement local.
- `.env.example` : variables d'environnement à renseigner sur le serveur.

## Sécurité
Ne mets jamais une clé API football, un mot de passe administrateur ou un secret JWT directement dans le frontend. Les secrets restent côté serveur.

## Étapes suivantes
1. Lancer PostgreSQL.
2. Connecter le backend V15 aux tables.
3. Ajouter migrations et validation.
4. Déployer l'API avec HTTPS.
5. Brancher le frontend V16.
