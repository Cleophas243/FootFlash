CREATE TABLE users (
  id INTEGER PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE players (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  position TEXT,
  nationality TEXT,
  club TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE competitions (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL,
  country TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE matches (
  id INTEGER PRIMARY KEY,
  competition_id INTEGER,
  home_team TEXT NOT NULL,
  away_team TEXT NOT NULL,
  home_score INTEGER NOT NULL DEFAULT 0,
  away_score INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'scheduled',
  minute INTEGER,
  kickoff_at TEXT,
  FOREIGN KEY (competition_id) REFERENCES competitions(id)
);

CREATE TABLE match_events (
  id INTEGER PRIMARY KEY,
  match_id INTEGER NOT NULL,
  minute INTEGER,
  type TEXT NOT NULL,
  player TEXT,
  detail TEXT,
  FOREIGN KEY (match_id) REFERENCES matches(id) ON DELETE CASCADE
);

CREATE TABLE news (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  category TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'draft',
  source_name TEXT,
  source_url TEXT,
  published_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE transfers (
  id INTEGER PRIMARY KEY,
  player_id INTEGER,
  from_club TEXT,
  to_club TEXT,
  fee TEXT,
  status TEXT NOT NULL DEFAULT 'rumor',
  source_name TEXT,
  source_url TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (player_id) REFERENCES players(id)
);

CREATE TABLE notifications (
  id INTEGER PRIMARY KEY,
  user_id INTEGER,
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  read_at TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX idx_matches_status ON matches(status);
CREATE INDEX idx_news_status_published ON news(status, published_at);
CREATE INDEX idx_events_match ON match_events(match_id, minute);
CREATE INDEX idx_transfers_status ON transfers(status);
