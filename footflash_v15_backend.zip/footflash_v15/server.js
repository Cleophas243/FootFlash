const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;
const DB = path.join(__dirname, 'data.json');

const seed = {
  news: [
    { id: 1, title: 'Breaking News de démonstration', category: 'Breaking', status: 'DEMO', createdAt: new Date().toISOString() }
  ],
  matches: [
    { id: 1, home: 'Manchester City', away: 'Arsenal', homeScore: 2, awayScore: 1, minute: 67, status: 'LIVE', competition: 'Premier League', events: [] }
  ],
  transfers: [],
  players: []
};

if (!fs.existsSync(DB)) fs.writeFileSync(DB, JSON.stringify(seed, null, 2));
function readDB() { return JSON.parse(fs.readFileSync(DB, 'utf8')); }
function writeDB(db) { fs.writeFileSync(DB, JSON.stringify(db, null, 2)); }
function send(res, code, data) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS' });
  res.end(JSON.stringify(data));
}
function body(req) { return new Promise((resolve, reject) => { let b=''; req.on('data', c => b+=c); req.on('end', () => { try { resolve(b ? JSON.parse(b) : {}); } catch(e) { reject(e); } }); }); }

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return send(res, 204, {});
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (url.pathname === '/api/health') return send(res, 200, { ok: true, app: 'FootFlash', version: 'V15' });
  if (url.pathname === '/api/news' && req.method === 'GET') return send(res, 200, readDB().news);
  if (url.pathname === '/api/matches' && req.method === 'GET') return send(res, 200, readDB().matches);
  if (url.pathname === '/api/transfers' && req.method === 'GET') return send(res, 200, readDB().transfers);
  if (url.pathname === '/api/players' && req.method === 'GET') return send(res, 200, readDB().players);

  if (req.method === 'POST' && url.pathname.startsWith('/api/admin/')) {
    const db = readDB(); const type = url.pathname.split('/').pop(); const data = await body(req);
    const collection = type === 'news' ? 'news' : type === 'matches' ? 'matches' : type === 'transfers' ? 'transfers' : type === 'players' ? 'players' : null;
    if (!collection) return send(res, 404, { error: 'Endpoint inconnu' });
    const item = { id: Date.now(), ...data, createdAt: new Date().toISOString() };
    db[collection].unshift(item); writeDB(db); return send(res, 201, item);
  }
  send(res, 404, { error: 'Route introuvable' });
});
server.listen(PORT, () => console.log(`FootFlash API running on http://localhost:${PORT}`));
