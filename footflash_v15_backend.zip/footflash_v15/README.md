# FootFlash V15 — API starter

Mini backend Node.js sans dépendance externe obligatoire.

## Lancer

```bash
npm start
```

Le serveur écoute sur le port 3000.

## Endpoints publics

- GET /api/health
- GET /api/news
- GET /api/matches
- GET /api/transfers
- GET /api/players

## Endpoints admin de démonstration

- POST /api/admin/news
- POST /api/admin/matches
- POST /api/admin/transfers
- POST /api/admin/players

Les données sont stockées dans `data.json`.

### Important
Cette V15 est un starter local. L'authentification Admin, HTTPS, validation stricte, rate limiting et une vraie base de données doivent être ajoutés avant toute mise en production.
