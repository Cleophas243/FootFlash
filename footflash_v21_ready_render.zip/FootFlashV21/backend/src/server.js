import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import pg from 'pg';
const { Pool } = pg;
const app = express();
const port = process.env.PORT || 3000;
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.DATABASE_URL && !process.env.DATABASE_URL.includes('localhost') ? { rejectUnauthorized:false } : false });
app.use(cors({origin:process.env.CORS_ORIGIN || '*'})); app.use(express.json());
app.get('/api/health', async (_req,res)=>{ try { await pool.query('select 1'); res.json({ok:true,service:'FootFlash V21',database:'connected'}); } catch(e){res.status(503).json({ok:false,service:'FootFlash V21',database:'unavailable'});} });
app.get('/api/matches/live', async (_req,res)=>{ const r=await pool.query("select * from matches where status in ('LIVE','HT') order by id desc"); res.json(r.rows); });
app.get('/api/news', async (_req,res)=>{ const r=await pool.query('select * from news order by published_at desc nulls last, id desc limit 50'); res.json(r.rows); });
app.get('/api/transfers', async (_req,res)=>{ const r=await pool.query('select * from transfers order by id desc limit 50'); res.json(r.rows); });
app.get('/api/players', async (_req,res)=>{ const r=await pool.query('select * from players order by name asc limit 100'); res.json(r.rows); });
app.post('/api/admin/sync/live', async (_req,res)=>{
  if(!process.env.FOOTBALL_API_KEY) return res.status(503).json({ok:false,error:'FOOTBALL_API_KEY is not configured'});
  try { const api=await fetch(`${process.env.FOOTBALL_API_BASE || 'https://v3.football.api-sports.io'}/fixtures?live=all`,{headers:{'x-apisports-key':process.env.FOOTBALL_API_KEY}}); if(!api.ok) return res.status(502).json({ok:false,error:`Provider HTTP ${api.status}`}); const data=await api.json();
    for(const item of (data.response||[])){ const f=item.fixture, teams=item.teams, goals=item.goals; await pool.query(`insert into matches (id,competition,home,away,home_score,away_score,minute,status) values ($1,$2,$3,$4,$5,$6,$7,$8) on conflict(id) do update set competition=excluded.competition,home=excluded.home,away=excluded.away,home_score=excluded.home_score,away_score=excluded.away_score,minute=excluded.minute,status=excluded.status`,[f.id,item.league?.name||'Football',teams.home?.name||'Home',teams.away?.name||'Away',goals.home||0,goals.away||0,f.status?.elapsed||0,f.status?.short||'LIVE']); }
    res.json({ok:true,synced:(data.response||[]).length});
  } catch(e){res.status(502).json({ok:false,error:'Football provider unavailable'});}
});
app.listen(port,()=>console.log(`FootFlash V21 listening on ${port}`));
