create table if not exists matches (id bigint primary key, competition text, home text not null, away text not null, home_score int default 0, away_score int default 0, minute int default 0, status text default 'NS');
create table if not exists news (id bigserial primary key,title text not null,body text,source text,status text default 'A_CONFIRM',published_at timestamptz default now());
create table if not exists transfers (id bigserial primary key,player text not null,from_club text,to_club text,status text,fee text,created_at timestamptz default now());
create table if not exists players (id bigserial primary key,name text not null,club text,position text,nationality text);
