# FootFlash V18 — PostgreSQL backend

Cette version relie l'API FootFlash à PostgreSQL.

## Démarrage
1. Copier `.env.example` vers `.env` et adapter `DATABASE_URL`.
2. Créer la base PostgreSQL.
3. Exécuter `sql/schema.sql`.
4. `npm install`
5. `npm start`

Endpoints principaux : `/api/health`, `/api/news`, `/api/matches`, `/api/matches/live`, `/api/matches/:id/events`, `/api/players`, `/api/transfers`, `/api/admin/news`, `/api/admin/transfers`.

Important : les routes `/api/admin/*` ne sont pas encore protégées par une authentification de production. Ne pas exposer ce serveur publiquement avant d'ajouter JWT/session sécurisée, validation, rate limiting, HTTPS et contrôle de rôle.
